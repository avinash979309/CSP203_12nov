1. run ./q1.sh

2. run ./4a.sh
	run gnuplot 4b.p
	run ./4c.sh
	run ./4d.sh
	
3. table.pdf is table of qus.1
	q5.pdf is pdf of question 5

4. git repo link:   https://github.com/maharshisoni24/CSP203.git
